# Сборка с телефона

Телефон нужен только для управления GitHub. Unreal Engine устанавливать на Android не требуется.

## Бесплатный GitHub-hosted runner

Он подходит для обычных проектов, но **не содержит Unreal Engine 5**. Поэтому одного нажатия Build для этого UE5 проекта недостаточно.

## Рабочая схема

Нужен self-hosted runner:

Android phone
 -> GitHub repository
 -> self-hosted PC/server with UE5
 -> RunUAT BuildCookRun
 -> APK Artifact
 -> download APK to phone

## Что требуется на runner

- Unreal Engine 5.6
- Android SDK
- Android NDK, совместимая с версией UE
- Java/JDK, требуемая UE
- Git
- подписывание APK (для тестовой сборки можно использовать debug/development signing)

## Почему не делается "UE5 внутри GitHub Actions"

UE5 не является обычным публичным apt-пакетом. GitHub runner не поставляется с движком. Автоматическая загрузка UE5 также требует соблюдения лицензии и доступа к Epic/исходникам.

Этот репозиторий специально не содержит движок Unreal Engine.
