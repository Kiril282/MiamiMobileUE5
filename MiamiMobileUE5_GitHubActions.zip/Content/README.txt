Content/
Добавьте сюда:
- Maps/MiamiPrototype
- Characters/Male
- Characters/Female
- Vehicles
- Weapons
- UI
- Audio
- AI
