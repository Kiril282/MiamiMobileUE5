#include "MiamiMobileVehicle.h"

AMiamiMobileVehicle::AMiamiMobileVehicle()
{
    PrimaryActorTick.bCanEverTick = true;
}

void AMiamiMobileVehicle::ApplyDamage(float Amount)
{
    Health = FMath::Clamp(Health - FMath::Max(0.f, Amount), 0.f, MaxHealth);
}

void AMiamiMobileVehicle::Repair()
{
    Health = MaxHealth;
}