using UnrealBuildTool;

public class MiamiMobile : ModuleRules
{
    public MiamiMobile(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core", "CoreUObject", "Engine", "InputCore",
            "EnhancedInput", "UMG", "Slate", "SlateCore",
            "AIModule", "NavigationSystem", "GameplayTasks",
            "ChaosVehicles", "ChaosVehiclesCore"
        });
    }
}