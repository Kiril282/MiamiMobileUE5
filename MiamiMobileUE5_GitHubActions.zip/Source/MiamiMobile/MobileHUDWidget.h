#pragma once
#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "MobileHUDWidget.generated.h"

UCLASS()
class MIAMIMOBILE_API UMobileHUDWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category="Mobile")
    void SetMoveInput(FVector2D Input);

    UFUNCTION(BlueprintCallable, Category="Mobile")
    void SetLookInput(FVector2D Input);

    UFUNCTION(BlueprintCallable, Category="Mobile")
    void FirePressed();

    UFUNCTION(BlueprintCallable, Category="Mobile")
    void EnterVehiclePressed();

    UFUNCTION(BlueprintPure, Category="Mobile")
    FVector2D GetMoveInput() const { return MoveInput; }

    UFUNCTION(BlueprintPure, Category="Mobile")
    FVector2D GetLookInput() const { return LookInput; }

protected:
    UPROPERTY(BlueprintReadOnly, Category="Mobile")
    FVector2D MoveInput = FVector2D::ZeroVector;

    UPROPERTY(BlueprintReadOnly, Category="Mobile")
    FVector2D LookInput = FVector2D::ZeroVector;
};