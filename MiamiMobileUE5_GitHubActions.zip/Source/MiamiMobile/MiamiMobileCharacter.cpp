#include "MiamiMobileCharacter.h"
#include "GameFramework/CharacterMovementComponent.h"

AMiamiMobileCharacter::AMiamiMobileCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
    GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
}

void AMiamiMobileCharacter::BeginPlay()
{
    Super::BeginPlay();
    GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
}

void AMiamiMobileCharacter::SetSprinting(bool bSprinting)
{
    GetCharacterMovement()->MaxWalkSpeed = bSprinting ? SprintSpeed : WalkSpeed;
}

void AMiamiMobileCharacter::MoveForward(float Value)
{
    if (Controller && !FMath::IsNearlyZero(Value))
        AddMovementInput(GetActorForwardVector(), Value);
}

void AMiamiMobileCharacter::MoveRight(float Value)
{
    if (Controller && !FMath::IsNearlyZero(Value))
        AddMovementInput(GetActorRightVector(), Value);
}

void AMiamiMobileCharacter::LookHorizontal(float Value)
{
    AddControllerYawInput(Value);
}

void AMiamiMobileCharacter::JumpPressed() { Jump(); }
void AMiamiMobileCharacter::SprintPressed() { SetSprinting(true); }
void AMiamiMobileCharacter::SprintReleased() { SetSprinting(false); }

void AMiamiMobileCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);
    PlayerInputComponent->BindAxis("MoveForward", this, &AMiamiMobileCharacter::MoveForward);
    PlayerInputComponent->BindAxis("MoveRight", this, &AMiamiMobileCharacter::MoveRight);
    PlayerInputComponent->BindAxis("LookHorizontal", this, &AMiamiMobileCharacter::LookHorizontal);
    PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &AMiamiMobileCharacter::JumpPressed);
    PlayerInputComponent->BindAction("Sprint", IE_Pressed, this, &AMiamiMobileCharacter::SprintPressed);
    PlayerInputComponent->BindAction("Sprint", IE_Released, this, &AMiamiMobileCharacter::SprintReleased);
}