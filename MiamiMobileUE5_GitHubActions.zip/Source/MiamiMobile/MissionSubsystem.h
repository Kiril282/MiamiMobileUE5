#pragma once
#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "MissionSubsystem.generated.h"

UENUM(BlueprintType)
enum class EMissionState : uint8
{
    Locked,
    Available,
    Active,
    Completed,
    Failed
};

USTRUCT(BlueprintType)
struct FMissionData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite) FName Id;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FText Title;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) FText Description;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 Reward = 0;
    UPROPERTY(EditAnywhere, BlueprintReadWrite) EMissionState State = EMissionState::Locked;
};

UCLASS()
class MIAMIMOBILE_API UMissionSubsystem : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category="Missions")
    void AddMission(FMissionData Mission);

    UFUNCTION(BlueprintCallable, Category="Missions")
    bool StartMission(FName MissionId);

    UFUNCTION(BlueprintCallable, Category="Missions")
    bool CompleteMission(FName MissionId);

    UFUNCTION(BlueprintPure, Category="Missions")
    FMissionData GetMission(FName MissionId) const;

private:
    UPROPERTY() TArray<FMissionData> Missions;
};