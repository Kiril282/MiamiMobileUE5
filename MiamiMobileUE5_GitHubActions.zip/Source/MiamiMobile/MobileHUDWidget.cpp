#include "MobileHUDWidget.h"

void UMobileHUDWidget::SetMoveInput(FVector2D Input)
{
    MoveInput = Input.GetClampedToMaxSize(1.f);
}

void UMobileHUDWidget::SetLookInput(FVector2D Input)
{
    LookInput = Input.GetClampedToMaxSize(1.f);
}

void UMobileHUDWidget::FirePressed()
{
}

void UMobileHUDWidget::EnterVehiclePressed()
{
}