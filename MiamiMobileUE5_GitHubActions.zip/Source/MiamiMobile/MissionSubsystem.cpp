#include "MissionSubsystem.h"

void UMissionSubsystem::AddMission(FMissionData Mission)
{
    Missions.Add(Mission);
}

bool UMissionSubsystem::StartMission(FName MissionId)
{
    for (FMissionData& M : Missions)
    {
        if (M.Id == MissionId && (M.State == EMissionState::Available || M.State == EMissionState::Locked))
        {
            M.State = EMissionState::Active;
            return true;
        }
    }
    return false;
}

bool UMissionSubsystem::CompleteMission(FName MissionId)
{
    for (FMissionData& M : Missions)
    {
        if (M.Id == MissionId && M.State == EMissionState::Active)
        {
            M.State = EMissionState::Completed;
            return true;
        }
    }
    return false;
}

FMissionData UMissionSubsystem::GetMission(FName MissionId) const
{
    for (const FMissionData& M : Missions)
        if (M.Id == MissionId) return M;
    return FMissionData();
}