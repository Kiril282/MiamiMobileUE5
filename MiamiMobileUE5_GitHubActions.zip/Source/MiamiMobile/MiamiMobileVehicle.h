#pragma once
#include "CoreMinimal.h"
#include "WheeledVehiclePawn.h"
#include "MiamiMobileVehicle.generated.h"

UCLASS()
class MIAMIMOBILE_API AMiamiMobileVehicle : public AWheeledVehiclePawn
{
    GENERATED_BODY()

public:
    AMiamiMobileVehicle();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Vehicle")
    float MaxHealth = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Vehicle")
    float Health = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Vehicle")
    int32 VehicleColorIndex = 0;

    UFUNCTION(BlueprintCallable, Category="Vehicle")
    void ApplyDamage(float Amount);

    UFUNCTION(BlueprintCallable, Category="Vehicle")
    void Repair();
};