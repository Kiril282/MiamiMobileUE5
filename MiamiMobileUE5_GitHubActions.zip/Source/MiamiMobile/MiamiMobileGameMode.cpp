#include "MiamiMobileGameMode.h"
#include "MiamiMobileCharacter.h"

AMiamiMobileGameMode::AMiamiMobileGameMode()
{
    DefaultPawnClass = AMiamiMobileCharacter::StaticClass();
}