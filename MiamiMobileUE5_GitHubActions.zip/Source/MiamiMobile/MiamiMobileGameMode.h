#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MiamiMobileGameMode.generated.h"

UCLASS()
class MIAMIMOBILE_API AMiamiMobileGameMode : public AGameModeBase
{
    GENERATED_BODY()
public:
    AMiamiMobileGameMode();
};