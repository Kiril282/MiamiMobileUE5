#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "MiamiMobileCharacter.generated.h"

UENUM(BlueprintType)
enum class EStoryCharacter : uint8
{
    Male,
    Female
};

UCLASS()
class MIAMIMOBILE_API AMiamiMobileCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    AMiamiMobileCharacter();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Story")
    EStoryCharacter StoryCharacter = EStoryCharacter::Male;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Player")
    float WalkSpeed = 350.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Player")
    float SprintSpeed = 650.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Player")
    float Health = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Player")
    float Armor = 0.f;

    UFUNCTION(BlueprintCallable, Category="Player")
    void SetSprinting(bool bSprinting);

protected:
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
    virtual void BeginPlay() override;

private:
    void MoveForward(float Value);
    void MoveRight(float Value);
    void LookHorizontal(float Value);
    void JumpPressed();
    void SprintPressed();
    void SprintReleased();
};