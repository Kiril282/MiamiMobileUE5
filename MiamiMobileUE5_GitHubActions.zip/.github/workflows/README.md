# GitHub Actions

Важное ограничение: GitHub-hosted runner не содержит Unreal Engine 5 и не может легально скачать UE5 из публичного репозитория без предоставленных Epic Games credentials/доступа к источнику UE.

Для реальной сборки необходимо один раз настроить self-hosted runner с установленным UE5 + Android SDK/NDK либо использовать собственный CI runner/образ с UE5.

Файл `build-android.yml` ниже выполняет проверку проекта и показывает место, где запускается `RunUAT BuildCookRun`.
